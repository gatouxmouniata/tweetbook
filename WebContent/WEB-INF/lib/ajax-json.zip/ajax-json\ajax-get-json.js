 { 
  "menu": "File", 
  "commands": [ 
      {
          "value": "New", 
          "action":"CreateDoc"
      }, 
      {
          "value": "Open", 
          "action": "OpenDoc"
      }, 
      {
          "value": "Close",
          "action": "CloseDoc"
      }
   ] 
} 
